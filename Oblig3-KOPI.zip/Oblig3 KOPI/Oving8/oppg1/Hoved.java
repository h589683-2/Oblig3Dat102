package oppg1;

public class Hoved {
public static void main(String [] args) {
		
		BS_Tre<Integer> treet = new BS_Tre<Integer>();
		
		treet.leggTil(13);
		treet.leggTil(11);
		treet.leggTil(9);
		treet.leggTil(5);
		treet.leggTil(3);
		
	
		System.out.println("lagt til");
	
		
	}
}
