package oppg1;

public class Hoved7 {

}
